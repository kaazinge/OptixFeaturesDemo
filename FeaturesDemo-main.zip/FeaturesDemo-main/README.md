# FeaturesDemo
FactoryTalk Optix FeaturesDemo. This contains most of the features exposed by FT Optix

## Informations
This demo was originally designed in Uniqo, it has been ported to Optix.

## Bugs
Please report all issues to the [ISSUES](https://github.com/SalesAndApplications/FeaturesDemo/issues) page
